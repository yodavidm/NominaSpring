package es.david;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.david.entidad.Empleado;
import es.david.repositorio.EmpleadoRepositorio;

@SpringBootApplication
public class NominaSpringApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(NominaSpringApplication.class, args);
	}

	@Autowired
	private EmpleadoRepositorio empleadoRepositorio;
	
	@Override
	public void run(String... args) throws Exception {
		/*Empleado empleado1 = new Empleado("53769597J","David","M",4,2);
		empleadoRepositorio.save(empleado1);
		
		Empleado empleado2 = new Empleado("53748363B","Lucia","F",1,2);
		empleadoRepositorio.save(empleado2); */

	}

}
