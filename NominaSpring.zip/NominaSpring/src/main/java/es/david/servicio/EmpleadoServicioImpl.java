package es.david.servicio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.david.entidad.Empleado;
import es.david.repositorio.EmpleadoRepositorio;

@Service
public class EmpleadoServicioImpl implements EmpleadoServicio {

	@Autowired
	private EmpleadoRepositorio empleadoRepositorio;

	@Override
	public List<Empleado> listarTodosLosEmpleados() {
		return empleadoRepositorio.findAll();
	}

	@Override
	public Empleado guardarEmpleado(Empleado empleado) {
		return empleadoRepositorio.save(empleado);
	}

	@Override
	public Empleado obtenerEmpleadoPorId(String dni) {
		return empleadoRepositorio.findById(dni).orElse(null);
	}

	@Override
	public Empleado actualizarEmpleado(Empleado empleado) {
		return empleadoRepositorio.save(empleado);
	}

	@Override
	public void eliminarEmpleado(String dni) {
		empleadoRepositorio.deleteById(dni);
	}

}
