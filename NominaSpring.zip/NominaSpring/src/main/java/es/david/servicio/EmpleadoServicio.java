package es.david.servicio;

import java.util.List;

import es.david.entidad.Empleado;

public interface EmpleadoServicio {
	
	public List<Empleado> listarTodosLosEmpleados();
	public Empleado guardarEmpleado(Empleado empleado);
	public Empleado obtenerEmpleadoPorId(String dni);
	public Empleado actualizarEmpleado(Empleado empleado);
	public void eliminarEmpleado(String dni);
	

}
