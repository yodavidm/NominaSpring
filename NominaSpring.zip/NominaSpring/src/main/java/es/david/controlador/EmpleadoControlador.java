package es.david.controlador;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import es.david.entidad.Empleado;
import es.david.servicio.EmpleadoServicio;


@Controller
public class EmpleadoControlador {

	@Autowired
	private EmpleadoServicio empleadoServicio;

	@GetMapping("/index")
	public String index(Model model) {
		model.addAttribute("index");
		return "index";
	}

	@GetMapping("/empleados/buscar")
	public String empleadoEncontrado(Model model) {
		model.addAttribute("buscarEmpleado");
		return "buscarEmpleado";

	}

	@PostMapping("/empleados/buscar")
	public String buscarEmpleadoPorDni(@RequestParam("dni") String dni, Model model) {
		Empleado empleado = empleadoServicio.obtenerEmpleadoPorId(dni);

		if (empleado != null) {
			model.addAttribute("empleado", empleadoServicio.obtenerEmpleadoPorId(dni));
			return "empleadoEncontrado";
		} else {
			model.addAttribute("error", "Empleado no encontrado");
			return "error";
		}
	}

	@GetMapping("/empleados")
	public String listarEmpleados(Model model) {
		model.addAttribute("empleados", empleadoServicio.listarTodosLosEmpleados());
		return "empleados"; // devuelve archivo empleados
	}

	@GetMapping("/empleados/nuevo")
	public String mostrarCrearEmpleadoFormulario(Model model) {
		Empleado empleado = new Empleado();
		model.addAttribute("empleado", empleado);
		return "crear_empleado";
	}

	@PostMapping("/empleados")
	public String guardarEmpleado(@ModelAttribute("empleado") Empleado empleado) {
		empleadoServicio.guardarEmpleado(empleado);
		return "redirect:/empleados";
	}

	@GetMapping("/empleados/editar/{dni}")
	public String mostrarFormularioEditar(@PathVariable String dni, Model model) {
		model.addAttribute("empleado", empleadoServicio.obtenerEmpleadoPorId(dni));
		return "editar_empleado";
	}

	@PostMapping("/empleados/{dni}")
	public String actualizarEmpleado(@PathVariable String dni, @ModelAttribute("empleado") Empleado empleado,
			Model model) {
		Empleado empleadoExistente = empleadoServicio.obtenerEmpleadoPorId(dni);

		empleadoExistente.setDni(dni);
		empleadoExistente.setNombre(empleado.getNombre());
		empleadoExistente.setSexo(empleado.getSexo());
		empleadoExistente.setCategoria(empleado.getCategoria());
		empleadoExistente.setAnyos(empleado.getAnyos());

		empleadoServicio.actualizarEmpleado(empleadoExistente);

		return "redirect:/empleados";
	}

	@GetMapping("/empleados/{dni}")
	public String eliminarEmpleado(@PathVariable String dni) {
		empleadoServicio.eliminarEmpleado(dni);
		return "redirect:/empleados";
	}


}
